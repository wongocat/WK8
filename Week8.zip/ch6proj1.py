def newton(number):
    """Returns the square root of number using Newton's method."""
    # Initialize the estimate to half of the input number
    estimate = number / 2
    
    # Keep improving the estimate until it converges to the actual square root
    while True:
        new_estimate = (estimate + number / estimate) / 2
        if abs(new_estimate - estimate) < 0.0001:
            return new_estimate
        estimate = new_estimate

def main():
    """Allows the user to compute square roots of inputs until she presses
    the enter/return key."""
    while True:
        # Prompt the user to enter a number or press enter/return to quit
        number_str = input("Enter a number to compute its square root (or press enter to quit): ")
        if number_str == "":
            break
        try:
            # Convert the input string to a number and compute its square root
            number = float(number_str)
            square_root = newton(number)
            print(f"The square root of {number} is {square_root}")
        except ValueError:
            # Handle invalid input (e.g. non-numeric input)
            print("Invalid input. Please enter a valid number.")
