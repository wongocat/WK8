def newton(number, estimate=1):
    """Returns the square root of number using Newton's method."""
    # Check if the estimate converges to the actual square root
    if abs(estimate * estimate - number) < 0.0001:
        return estimate
    
    # Update the estimate and recursively call newton() again
    new_estimate = (estimate + number / estimate) / 2
    return newton(number, new_estimate)

number = 16
square_root = newton(number)
print(f"The square root of {number} is {square_root}")
